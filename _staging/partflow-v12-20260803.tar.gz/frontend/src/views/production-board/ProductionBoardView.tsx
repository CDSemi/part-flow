import './production-board.css';

import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import { useConnectivity } from '../../app/connectivity-context';
import { getViewStatePreview } from '../../app/view-state';
import { AreaDot } from '../../components/indicators';
import {
  EmptyState,
  ErrorState,
  LoadingState,
} from '../../components/view-states';
import { areaByKey } from '../../mocks/areas';
import {
  MOCK_BOARD_ROWS,
  MOCK_BOARD_ROWS_LONG,
} from '../../mocks/production-board';
import { formatIsoDateShort } from '../dates';
import type { MockBoardRow, MockLocationRow } from '../view-models';
import {
  FALLBACK_PAGE_SIZE,
  fallbackPageBreaks,
  pageBreaksByHeight,
  sortBoardRows,
} from './board-logic';

const ROTATE_MS = 12_000;

/** Self-contained live clock: only this component rerenders per tick. */
function LiveClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  // One coherent clock block: the time leads, the date sits directly
  // beneath it as the secondary line (production-board.css).
  return (
    <span className="clockwrap">
      <span className="clock">
        {now.toLocaleTimeString(undefined, { hour12: false })}
      </span>
      <span className="clockdate">
        {now.toLocaleDateString(undefined, {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        })}
      </span>
    </span>
  );
}

/**
 * Concise operator wording for the state column. `on mch.` marks the
 * active-Machine rows; canonical Movement type names never appear in
 * board text. Stocked rows keep their quiet presentation (no tag —
 * the `total … pcs stocked` line already states it).
 */
function locationStateLabel(state: MockLocationRow['state']): string {
  switch (state) {
    case 'machine':
      return 'on mch.';
    case 'queue':
      return 'queue';
    case 'processing':
      return 'processing';
    case 'done':
      return 'done';
    default:
      return '';
  }
}

function BoardLocationRow({ loc }: { loc: MockLocationRow }) {
  const onMachine = loc.state === 'machine' && loc.machine !== undefined;
  // External activity (`plating`, `vendor`, …) replaces the generic
  // `processing` label with a light informational chip.
  const activityChip = loc.state === 'processing' && loc.activity;
  // The completing Machine (or External activity) on a done row is
  // secondary context only — it appears in the tooltip, never as the
  // current executor.
  const doneTitle =
    loc.state === 'done'
      ? loc.machine
        ? `Completed at ${loc.machine} — ready to transfer`
        : loc.activity
          ? `Completed (${loc.activity}) — ready to transfer`
          : 'Completed — ready to transfer'
      : undefined;
  return (
    <div className="locrow">
      <span className="lname">
        <AreaDot
          colorVar={areaByKey(loc.area)?.colorVar ?? 'var(--faint)'}
          size={11}
        />
        {onMachine ? (
          <span className="mchip" title={loc.machine}>
            {loc.machine}
          </span>
        ) : (
          loc.label
        )}
      </span>
      <span className="lqty">{loc.qty}</span>
      {activityChip ? (
        <span className="ltag">
          <span className="actchip">{loc.activity}</span>
        </span>
      ) : (
        <span
          className={`ltag${loc.state === 'done' ? ' done' : ''}`}
          title={doneTitle}
        >
          {locationStateLabel(loc.state)}
        </span>
      )}
      <span className={`ltime ${loc.timeLong ? 'long' : ''}`}>{loc.time}</span>
    </div>
  );
}

function BoardRowCells({ row, no }: { row: MockBoardRow; no: number }) {
  const urgent = row.dueClass === 'soon' || row.dueClass === 'late';
  return (
    <>
      <td className="cell-no">
        {/* The Hot flame lives in the No. column — the PN cell carries
            only the PN and description. */}
        <div
          className="no"
          aria-label={
            row.hotRank !== undefined ? `Row ${no}, Hot priority` : undefined
          }
        >
          {no}
          {row.hotRank !== undefined ? (
            <span className="hotflame" aria-hidden="true">
              {' '}
              🔥
            </span>
          ) : null}
        </div>
      </td>
      <td className="pn">
        <div className="part" title={row.pn}>
          {row.pn}
        </div>
        <div className="pname">{row.name}</div>
      </td>
      <td className="areas">
        <div className="loc">
          {row.locations.map((loc) => (
            <BoardLocationRow
              loc={loc}
              key={`${loc.area}-${loc.machine ?? ''}-${loc.state}`}
            />
          ))}
          {/* One continuous dashed separator spanning the complete
              location grid — never per-cell border fragments. */}
          <div className="locsep" aria-hidden="true" />
          <div className="locrow total">
            <span className="lname">total</span>
            <span className="lqty tot">{row.total}</span>
            <span className="ltag">
              pcs{row.totalStocked ? ' stocked' : ''}
            </span>
            <span className="ltime">
              {row.scrapped ? (
                // Scrap renders on the total line itself, anchored in
                // the right-hand time position as a quiet error-toned
                // chip — never an extra row, never a ⊘ symbol.
                <span className="scrapchip">{row.scrapped} scrapped</span>
              ) : null}
            </span>
          </div>
        </div>
      </td>
      <td className="due">
        <div className="d1">{formatIsoDateShort(row.due)}</div>
        {/* Only the urgency text blinks — never the PN, and the date
            itself stays steady. */}
        <div className={`d2 ${row.dueClass} ${urgent ? 'blink' : ''}`}>
          {row.dueNote}
        </div>
      </td>
      <td className="cell-days">
        <div className="dtotal">{row.totalDays}</div>
      </td>
      <td className="jobs">
        {row.jobs.map((job) => (
          <div className="j" key={job.job + job.meta}>
            {job.job} <span className="jm">{job.meta}</span>
          </div>
        ))}
      </td>
    </>
  );
}

function BoardColgroup() {
  return (
    <colgroup>
      <col className="col-no" />
      <col className="col-pn" />
      <col className="col-areas" />
      <col className="col-due" />
      <col className="col-days" />
      <col className="col-jobs" />
    </colgroup>
  );
}

function BoardHeadRow() {
  return (
    <tr>
      <th>No.</th>
      <th className="pn">Part Number</th>
      <th>Areas &amp; Quantities · Time</th>
      <th>Due Date</th>
      <th>Total Days</th>
      <th>Job Numbers</th>
    </tr>
  );
}

// Read-only large-display view: mock rows, no interactive elements.
// Pagination is calculated from the actual available board height and
// the actual rendered row heights (a hidden measurement table renders
// every row); it recalculates on viewport/container resize, data
// changes and theme/font-metric changes.
export function ProductionBoardView() {
  const preview = getViewStatePreview();
  const { status } = useConnectivity();

  const allRows: MockBoardRow[] = useMemo(() => {
    const raw =
      preview === 'empty' || preview === 'loading' || preview === 'error'
        ? []
        : preview === 'long'
          ? MOCK_BOARD_ROWS_LONG
          : MOCK_BOARD_ROWS;
    return sortBoardRows(raw);
  }, [preview]);

  const sectionRef = useRef<HTMLElement>(null);
  const headRef = useRef<HTMLDivElement>(null);
  const footRef = useRef<HTMLDivElement>(null);
  const measureTableRef = useRef<HTMLTableElement>(null);
  const measureBodyRef = useRef<HTMLTableSectionElement>(null);

  const [breaks, setBreaks] = useState<number[]>(() =>
    fallbackPageBreaks(allRows.length, FALLBACK_PAGE_SIZE),
  );

  const recalc = useCallback(() => {
    const section = sectionRef.current;
    const body = measureBodyRef.current;
    const table = measureTableRef.current;
    if (!section || !body || !table) return;
    const rowHeights = Array.from(body.rows, (row) => row.offsetHeight);
    const headHeight = headRef.current?.offsetHeight ?? 0;
    const theadHeight = table.tHead?.offsetHeight ?? 0;
    const footHeight = footRef.current?.offsetHeight ?? 0;
    const available =
      window.innerHeight -
      section.getBoundingClientRect().top -
      headHeight -
      theadHeight -
      footHeight;
    const usable =
      available > 0 &&
      rowHeights.length > 0 &&
      rowHeights.every((height) => height > 0);
    const next = usable
      ? pageBreaksByHeight(rowHeights, available)
      : fallbackPageBreaks(rowHeights.length, FALLBACK_PAGE_SIZE);
    setBreaks((current) =>
      current.length === next.length &&
      current.every((value, i) => value === next[i])
        ? current
        : next,
    );
  }, []);

  // Recalculate after every commit that can change row heights (data,
  // theme class, font metrics) — the measurement table re-renders in
  // the same commit, so useLayoutEffect reads fresh heights.
  useLayoutEffect(() => {
    recalc();
  }, [recalc, allRows]);

  useEffect(() => {
    window.addEventListener('resize', recalc);
    let observer: ResizeObserver | undefined;
    if (typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(() => recalc());
      if (sectionRef.current) observer.observe(sectionRef.current);
      if (measureTableRef.current) observer.observe(measureTableRef.current);
    }
    return () => {
      window.removeEventListener('resize', recalc);
      observer?.disconnect();
    };
  }, [recalc]);

  const pageCount = Math.max(1, breaks.length);

  const [page, setPage] = useState(0);
  // Every manual page change bumps the epoch, which recreates the
  // rotation interval — manual navigation restarts the auto-rotation
  // timer instead of racing it.
  const [rotateEpoch, setRotateEpoch] = useState(0);
  // Clamp the active page whenever the page structure changes.
  useEffect(() => {
    setPage((current) => Math.min(current, pageCount - 1));
  }, [pageCount]);
  // Rotate only while more than one page exists; the previous timer is
  // cleaned up when pagination changes, a manual navigation restarts
  // it, or the view unmounts. Automatic rotation wraps around; manual
  // navigation never does.
  useEffect(() => {
    if (pageCount <= 1) return;
    const timer = window.setInterval(
      () => setPage((current) => (current + 1) % pageCount),
      ROTATE_MS,
    );
    return () => window.clearInterval(timer);
  }, [pageCount, rotateEpoch]);
  const safePage = Math.min(page, pageCount - 1);

  /** Manual page change: clamped, non-wrapping, restarts the timer. */
  const goToPage = useCallback((target: number, currentPageCount: number) => {
    if (target < 0 || target >= currentPageCount) return;
    setPage(target);
    setRotateEpoch((epoch) => epoch + 1);
  }, []);

  // Physical-keyboard page navigation: ArrowLeft/ArrowRight work
  // regardless of focus (the board has no normal text-entry workflow),
  // never wrap, ignore modifier chords, stay inert while a modal
  // dialog is active, and restart the rotation timer like the buttons.
  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
      if (event.ctrlKey || event.altKey || event.metaKey) return;
      if (document.querySelector('[role="dialog"][aria-modal="true"]')) {
        return;
      }
      const target = safePage + (event.key === 'ArrowLeft' ? -1 : 1);
      if (target < 0 || target >= pageCount) return;
      // A valid page change consumes the key — no horizontal scroll.
      event.preventDefault();
      goToPage(target, pageCount);
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [safePage, pageCount, goToPage]);

  if (preview === 'loading') {
    return (
      <section className="pb" aria-label="Production Board">
        <LoadingState label="Loading Production Board" />
      </section>
    );
  }
  if (preview === 'error') {
    return (
      <section className="pb" aria-label="Production Board">
        <ErrorState
          message="The production feed could not be loaded."
          detail="The board retries automatically; data shown after recovery is complete and consistent."
        />
      </section>
    );
  }

  const start = breaks[safePage] ?? 0;
  const end = breaks[safePage + 1] ?? allRows.length;
  const rows = allRows.slice(start, end);
  const activePns = allRows.filter((r) => !r.totalStocked).length;
  const inProduction = allRows
    .filter((r) => !r.totalStocked)
    .reduce((s, r) => s + r.total, 0);
  const stocked = allRows
    .filter((r) => r.totalStocked)
    .reduce((s, r) => s + r.total, 0);
  const scrappedTotal = allRows.reduce((s, r) => s + (r.scrapped ?? 0), 0);

  return (
    <section className="pb" aria-label="Production Board" ref={sectionRef}>
      <div className="pb-head" ref={headRef}>
        <h1>Machine Shop — Production</h1>
        <span className={`live${status === 'connected' ? '' : ' stale'}`}>
          <span className="ld" aria-hidden="true" />
          {status === 'connected' ? 'Live' : 'Feed stale — reconnecting'}
        </span>
        <span className="spacer" />
        <LiveClock />
      </div>
      {rows.length === 0 ? (
        <EmptyState message="No active production in this Department." />
      ) : (
        <table className="pb-table">
          <BoardColgroup />
          <thead>
            <BoardHeadRow />
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr
                key={row.pn}
                className={
                  row.hotRank === 1
                    ? 'hotrow1'
                    : row.hotRank === 2
                      ? 'hotrow2'
                      : undefined
                }
              >
                <BoardRowCells row={row} no={start + index + 1} />
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {allRows.length > 0 ? (
        // Hidden measurement copy: every row renders here (identical
        // classes → identical metrics) so pages can be partitioned from
        // real heights without clipping.
        <div className="pb-measure" aria-hidden="true">
          <table className="pb-table" ref={measureTableRef}>
            <BoardColgroup />
            <thead>
              <BoardHeadRow />
            </thead>
            <tbody ref={measureBodyRef}>
              {allRows.map((row, index) => (
                <tr key={row.pn}>
                  <BoardRowCells row={row} no={index + 1} />
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      {/* Footer: a normal flex child anchored to the bottom of the
          board viewport (margin-top: auto — never position: fixed), so
          it stays part of layout, never covers table content, and its
          height stays inside the pagination measurement. Two readable
          rows: pagination controls + aggregate totals, then the
          legends including the user-facing sorting rule. */}
      <div className="pb-foot" ref={footRef}>
        <div className="pb-footrow">
          <span>
            {pageCount > 1
              ? `Page ${safePage + 1} / ${pageCount} · rotates every ${
                  ROTATE_MS / 1000
                } s`
              : 'Page 1 / 1'}
          </span>
          {/* Manual page navigation: Previous/Next never wrap (automatic
              rotation still does) and every manual change restarts the
              rotation timer. ArrowLeft/ArrowRight mirror the buttons. */}
          <span className="pgnav">
            <button
              className="pgbtn"
              aria-label="Previous page"
              disabled={safePage === 0}
              onClick={() => goToPage(safePage - 1, pageCount)}
            >
              ‹
            </button>
            {Array.from({ length: pageCount }, (_, i) => (
              <button
                key={i}
                className={`pgdot ${i === safePage ? 'on' : ''}`}
                aria-label={`Go to page ${i + 1}`}
                aria-current={i === safePage ? 'page' : undefined}
                onClick={() => goToPage(i, pageCount)}
              />
            ))}
            <button
              className="pgbtn"
              aria-label="Next page"
              disabled={safePage === pageCount - 1}
              onClick={() => goToPage(safePage + 1, pageCount)}
            >
              ›
            </button>
          </span>
          <span className="spacer" />
          <span>
            {activePns} active PNs · {inProduction} pcs in production ·{' '}
            {stocked} pcs stocked · {scrappedTotal} pcs scrapped
          </span>
        </div>
        <div className="pb-footrow legend">
          <span className="leg">
            🔥 in the No. column = Hot priority (highest first)
          </span>
          <span className="leg">
            blinking days count = due soon / overdue (the date and PN stay
            steady)
          </span>
          <span className="leg">— = no due date / no external WO Number</span>
          <span className="leg sort">
            Order: Hot rank first → earliest due date → no due date by oldest
            received date.
          </span>
        </div>
      </div>
    </section>
  );
}
